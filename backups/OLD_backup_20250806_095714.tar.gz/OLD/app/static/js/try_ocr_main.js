// app/static/js/try_ocr_main.js

class TryOcrMain {
  constructor() {
    this.pdfManager = new TryOcrPdf();
    this.engineManager = new TryOcrEngine();
    this.uiManager = new TryOcrUI();
    this.resizeManager = new TryOcrResize();
    this.processingInProgress = false;
    this.controller = null;
  }

  // 初期化
  initialize() {
    // UI初期化
    this.uiManager.initialize();

    // リサイズ機能初期化
    this.resizeManager.initialize();

    // DOM要素の取得
    this.processBtn = document.getElementById("process-btn");
    this.clearBtn = document.getElementById("clear-btn");
    this.compareAllBtn = document.getElementById("compare-all-btn");
    this.engineSelect = document.getElementById("engine-select");
    this.fileInput = document.getElementById("file-input");
    this.browseFileBtn = document.getElementById("browse-file");
    this.filePicker = document.getElementById("file-picker");
    this.pageNumInput = document.getElementById("page-num");

    // イベントリスナーの設定
    this.setupEventListeners();

    // OCRエンジンパラメータの初期読み込み
    this.engineManager.loadEngineParameters();

    // OCR設定ダイアログの初期化
    this.engineManager.initializeSettingsDialog();

    // OCR設定ダイアログの初期化のみ
    // 保存・プリセット機能は設定ダイアログ内で処理
  }

  // イベントリスナーの設定
  setupEventListeners() {
    // OCR実行ボタン
    if (this.processBtn) {
      this.processBtn.addEventListener("click", () => this.processOCR());
    }

    // キャンセルボタン
    this.cancelBtn = document.getElementById("cancel-btn");
    if (this.cancelBtn) {
      this.cancelBtn.addEventListener("click", () => this.cancelProcessing());
    }

    // 結果クリアボタン
    if (this.clearBtn) {
      this.clearBtn.addEventListener("click", () => this.uiManager.clearResults());
    }

    // ページ離脱警告
    window.addEventListener('beforeunload', (e) => {
      if (this.processingInProgress) {
        e.preventDefault();
        // 現代的なブラウザでは、カスタムメッセージは表示されないが、
        // preventDefault()により離脱確認ダイアログが表示される
        return 'OCR処理中です。ページを離れますか？';
      }
    });

    // 全エンジン比較ボタン
    if (this.compareAllBtn) {
      this.compareAllBtn.addEventListener("click", () => this.compareAllEngines());
    }

    // エンジン選択変更
    if (this.engineSelect) {
      this.engineSelect.addEventListener("change", () => {
        this.engineManager.loadEngineParameters();
      });
    }

    // ファイル選択
    if (this.browseFileBtn && this.filePicker) {
      this.browseFileBtn.addEventListener("click", () => {
        this.filePicker.click();
      });

      this.filePicker.addEventListener("change", (e) => {
        if (e.target.files.length > 0) {
          this.pdfManager.handleFileSelection(e.target.files[0]);
        }
      });
    }

    // ファイル入力フィールドの変更
    if (this.fileInput) {
      this.fileInput.addEventListener("change", () => {
        this.pdfManager.updatePdfPage();
      });
    }

    // ページ番号変更
    if (this.pageNumInput) {
      this.pageNumInput.addEventListener("change", () => {
        this.pdfManager.updatePdfPage();
      });
    }

    // PDF表示モード変更
    const pdfModeRadios = document.querySelectorAll('input[name="pdf_mode"]');
    pdfModeRadios.forEach(radio => {
      radio.addEventListener("change", () => {
        this.pdfManager.updatePdfDisplay();
      });
    });
  }

  // OCR処理実行
  async processOCR() {
    if (this.processingInProgress) {
      alert("既に処理が実行中です");
      return;
    }

    const selectedFile = this.pdfManager.getSelectedFile();
    const engineName = this.engineSelect.value;
    const pageNum = parseInt(this.pageNumInput.value) || 1;

    if (!selectedFile) {
      alert("ファイルを選択してください");
      return;
    }

    if (!engineName) {
      alert("OCRエンジンを選択してください");
      return;
    }

    this.processingInProgress = true;
    this.setFormDisabled(true);
    this.uiManager.showProcessing();
    this.uiManager.showProcessingStatus();

    // タイムアウト設定（5分）
    const TIMEOUT_MS = 5 * 60 * 1000;
    let timeoutId = null;

    try {
      this.controller = new AbortController();
      
      // タイムアウト処理を設定
      timeoutId = setTimeout(() => {
        console.warn('OCR処理がタイムアウトしました');
        this.controller.abort();
        this.uiManager.updateProcessingProgress('タイムアウトによりキャンセル中...');
      }, TIMEOUT_MS);
      
      const formData = new FormData();
      formData.append("file", selectedFile);
      formData.append("engine_name", engineName);
      formData.append("page_num", pageNum);

      // 誤字修正チェックボックスの値を追加
      const useCorrectionCheckbox = document.getElementById("use-correction-dict");
      formData.append("use_correction", useCorrectionCheckbox ? useCorrectionCheckbox.checked : false);

      // エンジンパラメータを追加
      const engineParams = this.engineManager.getCurrentEngineParameters();
      Object.keys(engineParams).forEach(key => {
        formData.append(`param_${key}`, engineParams[key]);
      });

      const response = await fetch("/api/try_ocr/process", {
        method: "POST",
        body: formData,
        signal: this.controller.signal
      });

      // 正常完了時はタイムアウトをクリア
      if (timeoutId) {
        clearTimeout(timeoutId);
        timeoutId = null;
      }

      const result = await response.json();

      if (result.success) {
        this.uiManager.displayResult(result);
      } else {
        this.uiManager.displayError(result.error || "OCR処理に失敗しました");
      }
    } catch (error) {
      // タイムアウトをクリア
      if (timeoutId) {
        clearTimeout(timeoutId);
        timeoutId = null;
      }
      
      if (error.name === 'AbortError') {
        this.uiManager.displayError("OCR処理がキャンセルまたはタイムアウトしました");
      } else {
        console.error("OCR処理エラー:", error);
        this.uiManager.displayError(`処理エラー: ${error.message}`);
      }
    } finally {
      // 確実にタイムアウトをクリア
      if (timeoutId) {
        clearTimeout(timeoutId);
      }
      this.onProcessingComplete();
    }
  }

  // キャンセル処理
  async cancelProcessing() {
    if (!this.processingInProgress) return;
    
    if (!confirm('OCR処理をキャンセルしますか？')) return;

    try {
      if (this.controller) {
        this.controller.abort();
      }
      this.uiManager.updateProcessingProgress('キャンセル中...');
    } catch (error) {
      console.error('キャンセルエラー:', error);
    }
  }

  // 処理完了時の処理
  onProcessingComplete() {
    this.processingInProgress = false;
    this.controller = null;
    this.setFormDisabled(false);
    this.uiManager.hideProcessing();
    this.uiManager.hideProcessingStatus();
  }

  // フォーム要素の有効/無効切り替え
  setFormDisabled(disabled) {
    if (this.processBtn) this.processBtn.disabled = disabled;
    if (this.compareAllBtn) this.compareAllBtn.disabled = disabled;
    if (this.engineSelect) this.engineSelect.disabled = disabled;
    if (this.pageNumInput) this.pageNumInput.disabled = disabled;
    if (this.browseFileBtn) this.browseFileBtn.disabled = disabled;
    if (this.cancelBtn) this.cancelBtn.disabled = !disabled;
  }



  // 全エンジン比較
  async compareAllEngines() {
    if (this.processingInProgress) {
      alert("既に処理が実行中です");
      return;
    }

    const selectedFile = this.pdfManager.getSelectedFile();
    const pageNum = parseInt(this.pageNumInput.value) || 1;

    if (!selectedFile) {
      alert("ファイルを選択してください");
      return;
    }

    // 利用可能なエンジンを取得
    const engines = [];
    for (let i = 0; i < this.engineSelect.options.length; i++) {
      const option = this.engineSelect.options[i];
      if (option.value) {
        engines.push(option.value);
      }
    }

    if (engines.length === 0) {
      alert("利用可能なOCRエンジンがありません");
      return;
    }

    this.processingInProgress = true;
    this.setFormDisabled(true);
    this.uiManager.showProcessing();
    this.uiManager.showProcessingStatus();

    // 全体タイムアウト設定（エンジン数 × 5分）
    const TIMEOUT_PER_ENGINE = 5 * 60 * 1000;
    const TOTAL_TIMEOUT = engines.length * TIMEOUT_PER_ENGINE;
    let globalTimeoutId = null;

    try {
      this.controller = new AbortController();
      
      // 全体タイムアウト処理を設定
      globalTimeoutId = setTimeout(() => {
        console.warn('全エンジン比較がタイムアウトしました');
        this.controller.abort();
        this.uiManager.updateProcessingProgress('タイムアウトによりキャンセル中...');
      }, TOTAL_TIMEOUT);
      
      // 各エンジンで順次処理
      for (const engineName of engines) {
        // キャンセルチェック
        if (this.controller.signal.aborted) {
          break;
        }

        this.uiManager.updateProcessingProgress(`${engineName} で処理中...`);

        const formData = new FormData();
        formData.append("file", selectedFile);
        formData.append("engine_name", engineName);
        formData.append("page_num", pageNum);

        // 誤字修正チェックボックスの値を追加
        const useCorrectionCheckbox = document.getElementById("use-correction-dict");
        formData.append("use_correction", useCorrectionCheckbox ? useCorrectionCheckbox.checked : false);

        // 個別エンジンのタイムアウト設定
        let engineTimeoutId = setTimeout(() => {
          console.warn(`${engineName} の処理がタイムアウトしました`);
          this.controller.abort();
        }, TIMEOUT_PER_ENGINE);

        try {
          const response = await fetch("/api/try_ocr/process", {
            method: "POST",
            body: formData,
            signal: this.controller.signal
          });

          // 正常完了時は個別タイムアウトをクリア
          if (engineTimeoutId) {
            clearTimeout(engineTimeoutId);
            engineTimeoutId = null;
          }

          const result = await response.json();

          if (result.success) {
            this.uiManager.displayResult(result);
          } else {
            this.uiManager.displayError(`${engineName}: ${result.error || "処理に失敗しました"}`);
          }
        } catch (error) {
          // 個別タイムアウトをクリア
          if (engineTimeoutId) {
            clearTimeout(engineTimeoutId);
            engineTimeoutId = null;
          }
          
          if (error.name === 'AbortError') {
            this.uiManager.displayError(`${engineName}: 処理がキャンセルまたはタイムアウトしました`);
            break;
          } else {
            console.error(`${engineName} エラー:`, error);
            this.uiManager.displayError(`${engineName}: ${error.message}`);
          }
        }

        // 次のエンジン処理前に少し待機（キャンセルチェック付き）
        if (!this.controller.signal.aborted) {
          await new Promise(resolve => setTimeout(resolve, 500));
        }
      }
    } finally {
      // 全体タイムアウトをクリア
      if (globalTimeoutId) {
        clearTimeout(globalTimeoutId);
      }
      this.onProcessingComplete();
    }
  }
}

// ページ読み込み時の初期化
document.addEventListener("DOMContentLoaded", () => {
  const tryOcrMain = new TryOcrMain();
  tryOcrMain.initialize();
  
  // グローバルに公開（デバッグ用）
  window.tryOcrMain = tryOcrMain;
});