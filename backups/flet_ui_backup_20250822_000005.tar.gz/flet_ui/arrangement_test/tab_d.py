#!/usr/bin/env python3
"""
Flet RAGシステム - 配置テスト タブD (縦スライダーレイヤー検討)
真のオーバーレイ縦スライダー実装
"""

import flet as ft
import math

# 定数定義
CENTER_W = 720           # 中央パネルの幅
CENTER_H = 420           # 中央パネルの高さ
GUIDE_W  = 36            # 青枠の幅（左/右ガイド）
SL_LEN   = 300           # 縦スライダーの"縦の長さ"（= Slider.width）
SL_THICK = 32            # スライダーの太さ（= Slider.height）
OVERHANG = 120           # 青枠の外側へ出す量（+なら外に張り出す）


class TabD:
    """タブD: 縦スライダーレイヤー検討"""
    
    def __init__(self):
        pass
    
    def create_content(self) -> ft.Control:
        """タブDコンテンツ作成"""
        # ---- 下層：背景
        base = ft.Container(expand=True, bgcolor=ft.Colors.SURFACE)
        
        # ---- 中央パネル（緑）
        center_panel = ft.Container(
            width=CENTER_W, height=CENTER_H,
            bgcolor=ft.Colors.SURFACE_VARIANT,
            border=ft.border.all(2, ft.Colors.GREEN_300),
            border_radius=12,
        )
        
        # ---- 左右の"青枠"ガイド（高さは中央パネルと同じ）
        left_guide = ft.Container(
            width=GUIDE_W, height=CENTER_H,
            bgcolor=ft.Colors.BLUE_50,
            border=ft.border.all(1, ft.Colors.BLUE_300)
        )
        
        right_guide = ft.Container(
            width=GUIDE_W, height=CENTER_H,
            bgcolor=ft.Colors.BLUE_50,
            border=ft.border.all(1, ft.Colors.BLUE_300)
        )
        
        # ---- 縦スライダー（回転）
        def vslider(val=50):
            return ft.Container(
                width=SL_LEN, height=SL_THICK,  # ← 縦の長さ / 太さ
                content=ft.Slider(
                    min=0, max=100, value=val, 
                    rotate=math.pi/2,
                    thumb_color=ft.Colors.BLUE_600,
                    active_color=ft.Colors.BLUE_400,
                    inactive_color=ft.Colors.GREY_300
                ),
                bgcolor=ft.Colors.RED_100,  # デバッグ用背景色
                border=ft.border.all(2, ft.Colors.RED_400)  # デバッグ用境界線
            )
        
        left_slider_holder  = ft.Container(content=vslider(30))
        right_slider_holder = ft.Container(content=vslider(70))
        
        # ---- 視覚的ガイドストリップ（40px幅）
        left_visual_strip = ft.Container(
            width=40, height=CENTER_H,
            bgcolor=ft.Colors.ORANGE_100,
            border=ft.border.all(1, ft.Colors.ORANGE_300)
        )
        
        right_visual_strip = ft.Container(
            width=40, height=CENTER_H,
            bgcolor=ft.Colors.ORANGE_100,
            border=ft.border.all(1, ft.Colors.ORANGE_300)
        )
        
        # ---- 重ねる（最後の要素ほど前面）
        root = ft.Stack(
            expand=True,
            clip_behavior=ft.ClipBehavior.NONE,  # 中央パネルの外にはみ出しを許可
            controls=[
                base,                                                    # 0: 背景
                ft.Container(content=center_panel, alignment=ft.alignment.center),  # 1: 中央パネル
                ft.Container(content=left_guide),                        # 2: 左ガイド（位置は place() で決める）
                ft.Container(content=right_guide),                       # 3: 右ガイド
                ft.Container(content=left_visual_strip),                 # 4: 左視覚ストリップ
                ft.Container(content=right_visual_strip),                # 5: 右視覚ストリップ
                left_slider_holder,                                      # 6: 左スライダー（最前面）
                right_slider_holder,                                     # 7: 右スライダー（最前面）
            ],
        )
        
        # 配置関数
        def place():
            """要素の配置計算と設定"""
            # ページサイズ取得（デフォルト値使用）
            vw, vh = 1000, 680
            
            # 中央パネルの左上（画面中央配置）
            panel_left = (vw - CENTER_W) / 2
            panel_top  = (vh - CENTER_H) / 2
            
            # 左右ガイドの位置
            lg = root.controls[2]
            rg = root.controls[3]
            lg.left, lg.top = panel_left - GUIDE_W, panel_top
            rg.left, rg.top = panel_left + CENTER_W, panel_top
            
            # 視覚的ガイドストリップの位置
            lvs = root.controls[4]
            rvs = root.controls[5]
            lvs.left, lvs.top = panel_left - GUIDE_W - 4, panel_top  # 青枠の4px左
            rvs.left, rvs.top = panel_left + CENTER_W + GUIDE_W + 4, panel_top  # 青枠の4px右
            
            # 縦中央に合わせる: top = panel_top + (H - L) / 2
            top_for_slider = panel_top + (CENTER_H - SL_LEN) / 2
            
            # 左スライダー（青枠の外へ OVERHANG ぶんはみ出す）
            left_slider_holder.top  = top_for_slider
            left_slider_holder.left = panel_left - OVERHANG - SL_THICK / 2 + 16  # 16px調整
            
            # 右スライダー（同様に外へ張り出す）
            right_slider_holder.top  = top_for_slider
            right_slider_holder.left = panel_left + CENTER_W + OVERHANG - SL_THICK / 2 - 16  # 16px調整
        
        # 初期配置
        place()
        
        return root

