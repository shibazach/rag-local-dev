#!/usr/bin/env python3
"""
Flet RAGシステム - 配置テスト タブE (総合展示)
Fletコントロールギャラリー
"""

import flet as ft
import webbrowser


class TabE:
    """タブE: 総合展示（Fletコントロールギャラリー）"""
    
    def __init__(self):
        pass
    
    def create_content(self) -> ft.Control:
        """タブEコンテンツ作成"""
        # レイアウトコントロール
        layout_section = self._create_section(
            "レイアウト",
            [
                ("Container", ft.Container(content=ft.Text("Container"), bgcolor=ft.Colors.BLUE_100, padding=10)),
                ("Row", ft.Row([ft.Text("Item1"), ft.Text("Item2"), ft.Text("Item3")])),
                ("Column", ft.Column([ft.Text("Item1"), ft.Text("Item2"), ft.Text("Item3")])),
                ("Stack", ft.Stack([
                    ft.Container(width=100, height=50, bgcolor=ft.Colors.RED_200),
                    ft.Container(width=50, height=25, bgcolor=ft.Colors.BLUE_200, left=25, top=12.5)
                ], width=100, height=50)),
            ],
            "layout"
        )
        
        # 入力コントロール
        input_section = self._create_section(
            "入力",
            [
                ("TextField", ft.TextField(label="テキスト入力", width=200)),
                ("Dropdown", ft.Dropdown(
                    options=[ft.dropdown.Option("選択肢1"), ft.dropdown.Option("選択肢2")],
                    label="ドロップダウン",
                    width=200
                )),
                ("Checkbox", ft.Checkbox(label="チェックボックス")),
                ("Switch", ft.Switch(label="スイッチ")),
                ("Slider", ft.Slider(min=0, max=100, value=50, width=200)),
                ("Radio", ft.RadioGroup(
                    content=ft.Row([
                        ft.Radio(value="1", label="選択肢1"),
                        ft.Radio(value="2", label="選択肢2")
                    ])
                )),
            ],
            "input"
        )
        
        # 表示コントロール
        display_section = self._create_section(
            "表示",
            [
                ("Text", ft.Text("テキスト表示")),
                ("Icon", ft.Icon(ft.Icons.STAR, color=ft.Colors.YELLOW, size=30)),
                ("Image", ft.Icon(ft.Icons.IMAGE, size=30)),  # 実際の画像の代わり
                ("ProgressBar", ft.ProgressBar(value=0.7, width=200)),
                ("ProgressRing", ft.ProgressRing(value=0.7, width=50)),
            ],
            "display"
        )
        
        # ボタンコントロール
        button_section = self._create_section(
            "ボタン",
            [
                ("ElevatedButton", ft.ElevatedButton("標準ボタン")),
                ("OutlinedButton", ft.OutlinedButton("アウトラインボタン")),
                ("TextButton", ft.TextButton("テキストボタン")),
                ("IconButton", ft.IconButton(icon=ft.Icons.FAVORITE, icon_color=ft.Colors.RED)),
                ("FloatingActionButton", ft.FloatingActionButton(icon=ft.Icons.ADD, mini=True)),
            ],
            "button"
        )
        
        # ナビゲーションコントロール
        navigation_section = self._create_section(
            "ナビゲーション",
            [
                ("Tabs", ft.Tabs(
                    tabs=[
                        ft.Tab(text="タブ1"),
                        ft.Tab(text="タブ2"),
                        ft.Tab(text="タブ3")
                    ],
                    width=300
                )),
                ("NavigationBar", ft.Text("NavigationBar（ページレベル）")),
                ("AppBar", ft.Text("AppBar（ページレベル）")),
            ],
            "navigation"
        )
        
        # メインレイアウト
        main_layout = ft.Column([
            ft.Text("🎨 Fletコントロールギャラリー", size=24, weight=ft.FontWeight.BOLD),
            ft.Text("各コントロールのサンプルと公式ドキュメントへのリンク", size=14, color=ft.Colors.GREY_600),
            ft.Divider(),
            layout_section,
            input_section,
            display_section,
            button_section,
            navigation_section
        ], scroll=ft.ScrollMode.AUTO, expand=True)
        
        return ft.Container(
            content=main_layout,
            expand=True,
            padding=ft.padding.all(16)
        )
    
    def _create_section(self, title: str, controls: list, category: str) -> ft.Container:
        """セクション作成"""
        control_items = []
        
        for name, control in controls:
            # コントロールアイテム
            item = ft.Container(
                content=ft.Column([
                    ft.Text(name, size=14, weight=ft.FontWeight.BOLD),
                    ft.Container(height=8),
                    control,
                    ft.Container(height=8),
                    ft.ElevatedButton(
                        "📖 ドキュメント",
                        on_click=lambda e, n=name: self._open_docs(n.lower()),
                        scale=0.8
                    )
                ], horizontal_alignment=ft.CrossAxisAlignment.CENTER),
                padding=ft.padding.all(16),
                bgcolor=ft.Colors.WHITE,
                border_radius=8,
                border=ft.border.all(1, ft.Colors.GREY_300),
                width=250
            )
            control_items.append(item)
        
        # セクションコンテンツ
        section_content = ft.Column([
            ft.Text(title, size=18, weight=ft.FontWeight.BOLD),
            ft.Container(height=8),
            ft.Row(
                controls=control_items,
                wrap=True,
                spacing=16,
                run_spacing=16
            )
        ])
        
        return ft.Container(
            content=section_content,
            padding=ft.padding.all(16),
            margin=ft.margin.only(bottom=24),
            bgcolor=ft.Colors.GREY_50,
            border_radius=12
        )
    
    def _open_docs(self, control_name: str):
        """ドキュメントを開く"""
        base_url = "https://flet-controls-gallery.fly.dev"
        
        # カテゴリマッピング
        category_map = {
            "container": "layout/container",
            "row": "layout/row",
            "column": "layout/column",
            "stack": "layout/stack",
            "textfield": "input/textfield",
            "dropdown": "input/dropdown",
            "checkbox": "input/checkbox",
            "switch": "input/switch",
            "slider": "input/slider",
            "radio": "input/radio",
            "text": "display/text",
            "icon": "display/icon",
            "image": "display/image",
            "progressbar": "display/progressbar",
            "progressring": "display/progressring",
            "elevatedbutton": "buttons/elevatedbutton",
            "outlinedbutton": "buttons/outlinedbutton",
            "textbutton": "buttons/textbutton",
            "iconbutton": "buttons/iconbutton",
            "floatingactionbutton": "buttons/floatingactionbutton",
            "tabs": "navigation/tabs",
            "navigationbar": "navigation/navigationbar",
            "appbar": "navigation/appbar"
        }
        
        path = category_map.get(control_name, "")
        if path:
            url = f"{base_url}/{path}"
            try:
                webbrowser.open(url)
                print(f"ドキュメントを開きました: {url}")
            except Exception as e:
                print(f"ドキュメントを開けませんでした: {e}")
        else:
            print(f"ドキュメントが見つかりません: {control_name}")

