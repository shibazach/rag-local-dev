import flet as ft
from .table import FilesTable
from ..shared.pdf_preview import PDFPreview

BOTTOM_BAR_H = 32
OUTER_PAD = 8


def show_files_page(page=None):
    """ファイル管理ページのメインコンテンツ"""
    if page:
        page.bgcolor = ft.Colors.GREY_50  # 全ページ統一背景色
    files_page = FilesPage()
    files_page.page = page  # Page参照を設定
    layout = files_page.create_main_layout()
    files_page.load_files()
    return layout


class FilesPage:
    """ファイル管理ページ（テーブル・プレビュー分離版）"""

    def __init__(self):
        self.files_table = FilesTable(on_file_select_callback=self.on_file_selected)
        self.pdf_preview = PDFPreview()
        # Page参照設定用（ページネーション更新で必要）
        self.page = None

        # 5段階比率: 1:5, 2:4, 3:3, 4:2, 5:1
        self.level = 3  # 初期値は3:3
        self.ratios = {
            1: (1, 5),  # 左:1, 右:5
            2: (2, 4),  # 左:2, 右:4  
            3: (3, 3),  # 左:3, 右:3
            4: (4, 2),  # 左:4, 右:2
            5: (5, 1),  # 左:5, 右:1
        }

        # UI参照
        self.page: ft.Page | None = None
        self.main_container: ft.Container | None = None
        self.left_container: ft.Container | None = None
        self.right_container: ft.Container | None = None
        self.width_slider: ft.Slider | None = None

    # ---- 内部：expand比率反映
    def _apply_ratios(self):
        if not self.left_container or not self.right_container:
            return
        left_expand, right_expand = self.ratios[self.level]
        self.left_container.expand = left_expand
        self.right_container.expand = right_expand
        # ページに追加済みの場合のみ更新
        try:
            if self.left_container.page:
                self.left_container.update()
            if self.right_container.page:
                self.right_container.update()
        except Exception as e:
            print(f"[DEBUG] Container update error: {e}")

    def create_main_layout(self):
        """メインレイアウト作成（5段階Sliderでexpand比率変更）"""
        print("[DEBUG] create_main_layout called")

        try:
            # FilesTableにpage参照を設定
            self.files_table.page = self.page
            
            # 左：ファイル一覧
            left_pane = self.files_table.create_table_widget()
            print(f"[DEBUG] Left pane created: {type(left_pane)}")

            # 右：PDFプレビュー
            right_pane = self.pdf_preview
            print(f"[DEBUG] Right pane created: {type(right_pane)}")

            # 左右コンテナ（expandで比率制御）
            left_expand, right_expand = self.ratios[self.level]
            self.left_container = ft.Container(
                content=left_pane,
                margin=ft.margin.all(0),  # margin統一削除
                padding=ft.padding.all(0),  # padding完全削除
                expand=left_expand,
            )
            self.right_container = ft.Container(
                content=right_pane,
                margin=ft.margin.all(0),  # margin統一削除
                padding=ft.padding.all(0),  # padding完全削除
                expand=right_expand,
            )

            # 左右ペイン境界線（グレー）
            divider = ft.VerticalDivider(width=1, thickness=1, color=ft.Colors.GREY_300)

            # 5段階スライダー
            self.width_slider = ft.Slider(
                min=1,
                max=5,
                value=self.level,
                divisions=4,
                label="{value}",
                on_change=self.on_slider_change,
                width=300,
            )

            # 上段：左右Row、下段：スライダ
            top_row = ft.Row(
                controls=[self.left_container, divider, self.right_container],
                spacing=0,
                expand=True,
                vertical_alignment=ft.CrossAxisAlignment.STRETCH,
            )

            bottom_bar = ft.Container(
                content=ft.Row(
                    controls=[self.width_slider],
                    alignment=ft.MainAxisAlignment.CENTER,
                ),
                height=BOTTOM_BAR_H,
                bgcolor=ft.Colors.GREY_50,
                border=ft.border.only(top=ft.BorderSide(1, ft.Colors.GREY_300)),
                padding=ft.padding.all(0),
            )

            self.main_container = ft.Container(
                content=ft.Column([top_row, bottom_bar], spacing=0, expand=True),
                padding=ft.padding.all(0),  # メインエリアのpaddingを削除
                expand=True,
            )

            # expandは既に設定済み（初期化時に設定）

            print("[DEBUG] 5-level Slider layout created successfully")

        except Exception as ex:
            import traceback
            traceback.print_exc()
            self.main_container = ft.Container(
                content=ft.Text(f"レイアウト作成エラー: {str(ex)}", color=ft.Colors.RED),
                padding=ft.padding.all(20),
            )

        return self.main_container

    def on_slider_change(self, e: ft.ControlEvent):
        """スライダ変更時に比率を更新"""
        try:
            self.level = int(float(e.control.value))
        except Exception:
            pass
        self._apply_ratios()

    def load_files(self):
        """ファイル一覧のロード"""
        self.files_table.load_files()

    def on_file_selected(self, file_id):
        """ファイル選択時のプレビュー表示"""
        if file_id:
            file_info = self.files_table.get_selected_file()
            self.pdf_preview.show_pdf_preview(file_info)
        else:
            self.pdf_preview.show_empty_preview()