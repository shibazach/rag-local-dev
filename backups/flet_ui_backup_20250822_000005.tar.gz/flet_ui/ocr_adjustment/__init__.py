#!/usr/bin/env python3
"""
Flet RAGシステム - OCR調整ページ
4分割レイアウト + 3つのスライダー制御
"""

