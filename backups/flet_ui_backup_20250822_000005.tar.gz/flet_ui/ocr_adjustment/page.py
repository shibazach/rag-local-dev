#!/usr/bin/env python3
"""
Flet RAGシステム - OCR調整ページメイン
4分割レイアウト + 3つのスライダー制御
"""

import flet as ft
import math

class OCRAdjustmentPage:
    """OCR調整ページ（4分割レイアウト + 3スライダー制御）"""
    
    def __init__(self):
        """初期化"""
        self.left_split_level = 3
        self.right_split_level = 3
        self.horizontal_level = 3

    def create_main_layout(self):
        """メインレイアウト作成（4分割 + 3スライダー）"""
        print("[DEBUG] OCR Adjustment create_main_layout called")
        
        # 4つのペイン作成
        top_left = self._create_ocr_settings_pane()
        bottom_left = self._create_ocr_results_pane()
        top_right = self._create_engine_details_pane()
        bottom_right = self._create_pdf_preview_pane()
        
        # 左ペイン（上下分割）
        left_column = ft.Column([
            top_left,
            ft.Divider(height=1, thickness=1, color=ft.Colors.GREY_300),
            bottom_left
        ], expand=True, spacing=0)
        
        # 右ペイン（上下分割）
        right_column = ft.Column([
            top_right,
            ft.Divider(height=1, thickness=1, color=ft.Colors.GREY_300),
            bottom_right
        ], expand=True, spacing=0)
        
        # メインROW（左右分割）
        main_row = ft.Row([
            left_column,
            ft.VerticalDivider(width=1, thickness=1, color=ft.Colors.GREY_300),
            right_column
        ], spacing=0, expand=True)
        
        # 3つのスライダー作成
        left_slider = ft.Slider(
            min=1, max=5, value=self.left_split_level, divisions=4, label="{value}",
            on_change=self.on_left_split_change,
            expand=1, height=30, rotate=math.pi / 2,
        )
        
        right_slider = ft.Slider(
            min=1, max=5, value=self.right_split_level, divisions=4, label="{value}",
            on_change=self.on_right_split_change,
            expand=1, height=30, rotate=math.pi / 2,
        )
        
        horizontal_slider = ft.Slider(
            min=1, max=5, value=self.horizontal_level, divisions=4, label="{value}",
            on_change=self.on_horizontal_change, width=300,
        )
        
        # 左サイドバー
        left_sidebar = ft.Container(
            content=ft.Column([left_slider], alignment=ft.MainAxisAlignment.CENTER, expand=True),
            width=36, bgcolor=ft.Colors.GREY_50,
            border=ft.border.only(right=ft.BorderSide(1, ft.Colors.GREY_300)),
        )
        
        # 右サイドバー
        right_sidebar = ft.Container(
            content=ft.Column([right_slider], alignment=ft.MainAxisAlignment.CENTER, expand=True),
            width=36, bgcolor=ft.Colors.GREY_50,
            border=ft.border.only(left=ft.BorderSide(1, ft.Colors.GREY_300)),
        )
        
        # トップレベルROW
        top_row = ft.Row([
            left_sidebar,
            ft.Container(content=main_row, expand=True),
            right_sidebar
        ], spacing=0, expand=True)
        
        # ボトムバー
        bottom_bar = ft.Container(
            content=ft.Row([horizontal_slider], alignment=ft.MainAxisAlignment.CENTER),
            height=32, bgcolor=ft.Colors.GREY_50,
            border=ft.border.only(top=ft.BorderSide(1, ft.Colors.GREY_300)),
        )
        
        # メインコンテナ
        return ft.Container(
            content=ft.Column([
                ft.Container(content=top_row, expand=True),
                bottom_bar
            ], spacing=0, expand=True),
            expand=True, bgcolor=ft.Colors.GREY_50
        )

    def _create_ocr_settings_pane(self):
        """左上: OCR設定ペイン"""
        return ft.Container(
            content=ft.Column([
                ft.Container(
                    content=ft.Row([
                        ft.Icon(ft.Icons.SETTINGS, size=20, color=ft.Colors.WHITE),
                        ft.Text("OCR設定", size=16, weight=ft.FontWeight.BOLD, color=ft.Colors.WHITE)
                    ], alignment=ft.MainAxisAlignment.START),
                    height=54, padding=ft.padding.symmetric(horizontal=16, vertical=8),
                    bgcolor=ft.Colors.BLUE_GREY_800,
                ),
                ft.Container(
                    content=ft.Column([
                        ft.Text("ファイルをドラッグ&ドロップ\nまたはボタンで選択", 
                               text_align=ft.TextAlign.CENTER, color=ft.Colors.GREY_600, size=14),
                        ft.Container(height=16),
                        ft.ElevatedButton("📁 ファイル選択", width=200, height=36),
                        ft.Container(height=16),
                        ft.ElevatedButton("🚀 OCR実行", width=200, height=36, 
                                        bgcolor=ft.Colors.BLUE_600, color=ft.Colors.WHITE)
                    ], horizontal_alignment=ft.CrossAxisAlignment.CENTER),
                    expand=True, alignment=ft.alignment.center
                )
            ], spacing=0),
            expand=True, margin=ft.margin.all(4), bgcolor=ft.Colors.WHITE,
            border_radius=8, border=ft.border.all(1, ft.Colors.GREY_300)
        )

    def _create_engine_details_pane(self):
        """右上: エンジン詳細設定ペイン"""
        return ft.Container(
            content=ft.Column([
                ft.Container(
                    content=ft.Row([
                        ft.Icon(ft.Icons.BUILD, size=20, color=ft.Colors.WHITE),
                        ft.Text("詳細設定", size=16, weight=ft.FontWeight.BOLD, color=ft.Colors.WHITE)
                    ], alignment=ft.MainAxisAlignment.START),
                    height=54, padding=ft.padding.symmetric(horizontal=16, vertical=8),
                    bgcolor=ft.Colors.BLUE_GREY_800,
                ),
                ft.Container(
                    content=ft.Column([
                        ft.Icon(ft.Icons.SETTINGS, size=60, color=ft.Colors.GREY_400),
                        ft.Container(height=12),
                        ft.Text("OCRエンジンを選択すると", size=14, color=ft.Colors.GREY_600, text_align=ft.TextAlign.CENTER),
                        ft.Text("詳細設定が表示されます", size=14, color=ft.Colors.GREY_600, text_align=ft.TextAlign.CENTER),
                    ], horizontal_alignment=ft.CrossAxisAlignment.CENTER),
                    expand=True, alignment=ft.alignment.center
                )
            ], spacing=0),
            expand=True, margin=ft.margin.all(4), bgcolor=ft.Colors.WHITE,
            border_radius=8, border=ft.border.all(1, ft.Colors.GREY_300)
        )

    def _create_ocr_results_pane(self):
        """左下: OCR結果ペイン"""
        return ft.Container(
            content=ft.Column([
                ft.Container(
                    content=ft.Row([
                        ft.Icon(ft.Icons.TEXT_SNIPPET, size=20, color=ft.Colors.WHITE),
                        ft.Text("OCR結果", size=16, weight=ft.FontWeight.BOLD, color=ft.Colors.WHITE)
                    ], alignment=ft.MainAxisAlignment.START),
                    height=54, padding=ft.padding.symmetric(horizontal=16, vertical=8),
                    bgcolor=ft.Colors.BLUE_GREY_800,
                ),
                ft.Container(
                    content=ft.Column([
                        ft.Icon(ft.Icons.TEXT_SNIPPET, size=60, color=ft.Colors.GREY_400),
                        ft.Container(height=12),
                        ft.Text("OCR実行すると", size=14, color=ft.Colors.GREY_600, text_align=ft.TextAlign.CENTER),
                        ft.Text("結果がここに表示されます", size=14, color=ft.Colors.GREY_600, text_align=ft.TextAlign.CENTER),
                    ], horizontal_alignment=ft.CrossAxisAlignment.CENTER),
                    expand=True, alignment=ft.alignment.center
                )
            ], spacing=0),
            expand=True, margin=ft.margin.all(4), bgcolor=ft.Colors.WHITE,
            border_radius=8, border=ft.border.all(1, ft.Colors.GREY_300)
        )

    def _create_pdf_preview_pane(self):
        """右下: PDFプレビューペイン"""
        return ft.Container(
            content=ft.Column([
                ft.Container(
                    content=ft.Row([
                        ft.Icon(ft.Icons.PICTURE_AS_PDF, size=20, color=ft.Colors.WHITE),
                        ft.Text("PDFプレビュー", size=16, weight=ft.FontWeight.BOLD, color=ft.Colors.WHITE)
                    ], alignment=ft.MainAxisAlignment.START),
                    height=54, padding=ft.padding.symmetric(horizontal=16, vertical=8),
                    bgcolor=ft.Colors.BLUE_GREY_800,
                ),
                ft.Container(
                    content=ft.Column([
                        ft.Icon(ft.Icons.PICTURE_AS_PDF, size=60, color=ft.Colors.GREY_400),
                        ft.Container(height=12),
                        ft.Text("ファイルを選択すると", size=14, color=ft.Colors.GREY_600, text_align=ft.TextAlign.CENTER),
                        ft.Text("PDFプレビューが表示されます", size=14, color=ft.Colors.GREY_600, text_align=ft.TextAlign.CENTER),
                    ], horizontal_alignment=ft.CrossAxisAlignment.CENTER),
                    expand=True, alignment=ft.alignment.center
                )
            ], spacing=0),
            expand=True, margin=ft.margin.all(4), bgcolor=ft.Colors.WHITE,
            border_radius=8, border=ft.border.all(1, ft.Colors.GREY_300)
        )

    def on_left_split_change(self, e):
        """左ペイン分割スライダー変更"""
        self.left_split_level = int(float(e.control.value))
        print(f"[DEBUG] Left split level changed to: {self.left_split_level}")

    def on_right_split_change(self, e):
        """右ペイン分割スライダー変更"""
        self.right_split_level = int(float(e.control.value))
        print(f"[DEBUG] Right split level changed to: {self.right_split_level}")

    def on_horizontal_change(self, e):
        """左右分割スライダー変更"""
        self.horizontal_level = int(float(e.control.value))
        print(f"[DEBUG] Horizontal level changed to: {self.horizontal_level}")

def show_ocr_adjustment_page(page: ft.Page = None):
    """OCR調整ページ表示関数"""
    if page:
        page.bgcolor = ft.Colors.GREY_50
    
    ocr_page = OCRAdjustmentPage()
    layout = ocr_page.create_main_layout()
    return layout

