#!/usr/bin/env python3
"""
Flet RAGシステム - PDFプレビューコンポーネント
"""

import flet as ft
from typing import Optional


class PDFPreview(ft.Container):
    """PDFプレビューコンポーネント"""
    
    def __init__(self, file_path: Optional[str] = None):
        super().__init__()
        self.file_path = file_path
        self.expand = True
        self.margin = ft.margin.all(4)  # 4px margin
        self._create_content()
    
    def _create_content(self):
        """コンテンツ作成"""
        if self.file_path:
            # 実際のPDFファイルがある場合
            content = ft.Column([
                ft.Text(f"PDFファイル: {self.file_path}", size=14, weight=ft.FontWeight.BOLD),
                ft.Container(height=8),
                ft.Text("PDFプレビュー機能は実装中です", size=12, color=ft.Colors.GREY_600),
                ft.Container(
                    content=ft.Icon(ft.Icons.PICTURE_AS_PDF, size=100, color=ft.Colors.GREY_400),
                    expand=True,
                    alignment=ft.alignment.center
                )
            ])
        else:
            # ファイルが選択されていない場合
            content = ft.Column([
                ft.Container(
                    content=ft.Column([
                        ft.Icon(ft.Icons.PICTURE_AS_PDF, size=80, color=ft.Colors.GREY_400),
                        ft.Container(height=16),
                        ft.Text("ファイルを選択すると", size=16, color=ft.Colors.GREY_600, text_align=ft.TextAlign.CENTER),
                        ft.Text("PDFプレビューが表示されます", size=16, color=ft.Colors.GREY_600, text_align=ft.TextAlign.CENTER)
                    ], horizontal_alignment=ft.CrossAxisAlignment.CENTER),
                    expand=True,
                    alignment=ft.alignment.center
                )
            ])
        
        self.content = ft.Container(
            content=content,
            expand=True,
            padding=ft.padding.all(16),
            bgcolor=ft.Colors.WHITE,
            border_radius=8,
            border=ft.border.all(1, ft.Colors.GREY_300)
        )
    
    def update_file(self, file_path: Optional[str]):
        """ファイル更新"""
        self.file_path = file_path
        self._create_content()
        self.update()


def create_pdf_preview(file_path: Optional[str] = None) -> PDFPreview:
    """PDFプレビュー作成関数"""
    return PDFPreview(file_path)

