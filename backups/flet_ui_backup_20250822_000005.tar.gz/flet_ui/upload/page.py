#!/usr/bin/env python3
"""
Flet RAGシステム - アップロードページメイン
1:2横分割（左:右）+ 左ペイン1:1縦分割 + リアルタイムログ
"""

import flet as ft
from .components import FileUploadArea, FolderUploadArea, RealTimeLogArea

def show_upload_page(page: ft.Page = None):
    """アップロードページ表示関数"""
    if page:
        page.bgcolor = ft.Colors.GREY_50
    
    # 左ペイン（上下1:1分割）
    file_upload_area = FileUploadArea()
    folder_upload_area = FolderUploadArea()
    
    left_pane = ft.Column([
        file_upload_area,
        ft.Container(height=8),  # 隙間
        folder_upload_area
    ], expand=1, spacing=0)
    
    # 右ペイン（リアルタイムログ）
    right_pane = ft.Container(
        content=RealTimeLogArea(),
        expand=2  # 1:2の比率
    )
    
    # メインレイアウト（左右1:2分割）
    main_layout = ft.Row([
        left_pane,
        ft.Container(width=8),  # 隙間
        right_pane
    ], expand=True, spacing=0)
    
    return ft.Container(
        content=main_layout,
        expand=True,
        margin=ft.margin.all(4),
        padding=ft.padding.all(4)
    )
