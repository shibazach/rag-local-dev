# new/api/__init__.py
# APIルーター一括エクスポート

from .files import router as files_router
from .upload import router as upload_router