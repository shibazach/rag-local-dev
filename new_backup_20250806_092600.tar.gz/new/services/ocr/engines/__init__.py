# new/services/ocr/engines/__init__.py
# OCRエンジン実装

__all__ = []