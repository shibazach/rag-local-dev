# new/services/ocr_comparison/__init__.py
# OCR比較検証サービスパッケージ初期化

from .correction_service import CorrectionService

__all__ = ['CorrectionService']